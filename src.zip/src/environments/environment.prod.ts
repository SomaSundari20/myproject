export const environment = {
  firebase: {
    projectId: 'httpsignup-69c32',
    appId: '1:346615725380:web:28a261a3568a2d06092b11',
    databaseURL: 'https://httpsignup-69c32-default-rtdb.firebaseio.com',
    storageBucket: 'httpsignup-69c32.appspot.com',
    apiKey: 'AIzaSyDMymHYuQEWDsc3CbciG6tfGIpes7w_ECI',
    authDomain: 'httpsignup-69c32.firebaseapp.com',
    messagingSenderId: '346615725380',
  },
  production: true
};
