import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldstu',
  templateUrl: './oldstu.component.html',
  styleUrls: ['./oldstu.component.css']
})
export class OldstuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
