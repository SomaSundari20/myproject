import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeinside',
  templateUrl: './homeinside.component.html',
  styleUrls: ['./homeinside.component.css']
})
export class HomeinsideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
