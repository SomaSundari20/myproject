import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Database, set, ref, onValue } from '@angular/fire/database';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {

  constructor(public router: Router, public dialog: MatDialog, public database: Database) { }

  ngOnInit(): void {

  }

  infoForm = new FormGroup({
    name: new FormControl('', Validators.required)
  })
  
  Save(value: any) {


    set(ref(this.database, 'info/' + value.name), {
      name: value.name,
      // email: value.email,
      // phone: value.phone,
      // designation: value.designation,
      // date: value.date,
      // status: value.status
    });
    alert('Contact saved')
this.infoForm.reset()
  }


  onClose() {

    this.router.navigate(['/homeinfo'])
  }

}
