import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { InfoComponent } from '../info/info.component';


@Component({
  selector: 'app-homeinfo',
  templateUrl: './homeinfo.component.html',
  styleUrls: ['./homeinfo.component.css']
})
export class HomeinfoComponent implements OnInit {

  constructor( public router: Router,public dialog : MatDialog) { }

  info : any  
  ngOnInit(): void {

  }
  add(){
    this.router.navigateByUrl('/info')
   this.dialog.open(InfoComponent,{width : '400px', height :'400px'})
  }
  
}
