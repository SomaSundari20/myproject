import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { InstitutionComponent } from '../institution/institution.component';

@Component({
  selector: 'app-homeins',
  templateUrl: './homeins.component.html',
  styleUrls: ['./homeins.component.css']
})
export class HomeinsComponent implements OnInit {

  constructor(public dialog: MatDialog, public router : Router) { }

  ngOnInit(): void {
  }

  onClick() {
    this.dialog.open(InstitutionComponent, { width: '2000px', height: '800px' })
this.router.navigate(['/homeinfo'])
  }
}
