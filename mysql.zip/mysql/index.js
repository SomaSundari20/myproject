const express = require('express');
const cors = require('cors');
const bodyparser = require('body-parser');
const mysql = require('mysql2');
const { get } = require('express/lib/response');
const req = require('express/lib/request');
const res = require('express/lib/response');
const { application } = require('express');



const app = express();
app.use(cors());
app.use(bodyparser.json())

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projectbd',
    port: 3306
})

db.connect(err => {
    if (err) {
        console.log(err)
    }
    console.log('Database connected..')
})

// info details.....//

//get all data
app.get('/info', (req, res) => {
    let qr = `select * from info`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'all info data',
                data: result
            })
        }
        else {
            console.log('Data not found')
        }
    })
})

// get single data

app.get('/info/:id', (req, res) => {

    let gId = req.params.id;

    let qr = `select * from info where id = ${gId}`

    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'Get single data',
                data: result
            })
        }
        else {
            res.send({
                message: 'data not found'
            })
        }
    })
})
// post data

app.post('/info', (req, res) => {

    // console.log(req.body, 'createdata');

    // let bookid = req.body.bookid;
    // let bookname = req.body.bookname;
    // let author = req.body.author;

    // let qr = ` insert into info (bookid,bookname,author) 
    //                 values ( '${bookid}' ,'${bookname}','${author}' )`;

    // db.query(qr, (err, result) => {
    //     if (err) { console.log(err) }
    //     console.log(result, 'result')
    //     res.send({
    //         message: 'Data Inserted'
    //     })
    // })
})
//update data//

app.put('/info/:id', (req, res) => {
    // console.log(req.body, 'updatedata');

    // let gId = req.params.id;
    // let bookid = req.body.bookid;
    // let bookname = req.body.bookname;
    // let author = req.body.author;

    // let qr = `update book set bookid = '${bookid}' ,bookname = '${bookname}' ,author = '${author}'
    //             where id = ${gId}`;

    // db.query(qr, (err, result) => {
    //     if (err) { console.log('err') }
    //     res.send({
    //         message: 'Data updated'
    //     })
    // })
})
//delete data
app.delete('/info/:id', (req, res) => {
    let gId = req.params.id;
    let qr = `delete from info where id = '${gId}'`;
    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        res.send({
            message: 'Data Deleted'
        })
    })
})


// contact details.....//
app.get('/contact', (req, res) => {
    let qr = `select * from contact`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'all book data',
                data: result
            })
        }
    })
})
app.get('/contact/:id', (req, res) => {

    let gId = req.params.id;

    let qr = `select * from contact where id = ${gId}`

    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'Get single data',
                data: result
            })
        }
        else {
            res.send({
                message: 'data not found'
            })
        }
    })
})
app.post('/contact', (req, res) => {

    console.log(req.body, 'createdata');

    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let designation = req.body.designation;
    let status = req.body.status;
    let date = req.body.date;

    let qr = ` insert into contact (name,phone,email,designation,status,date) 
                    values ( '${name}' ,'${phone}','${email}', '${designation}', '${status}', '${date}' )`;

    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        console.log(result, 'result')
        res.send({
            message: 'Data Inserted'
        })
    })
})
app.put('/contact/:id', (req, res) => {
    console.log(req.body, 'updatedata');

    let gId = req.params.id;
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let designation = req.body.designation;
    let status = req.body.status;
    let date = req.body.date;

    let qr = `update contact set name = '${name}' ,email = '${email}' ,phone = '${phone}',designation='${designation}' ,status='${status}',date='${date}'
                    where id = ${gId}`;

    db.query(qr, (err, result) => {
        if (err) { console.log('err') }
        res.send({
            message: 'Data updated'
        })
    })
})
//delete data
app.delete('/contact/:id', (req, res) => {
    let gId = req.params.id;
    let qr = `delete from contact where id = '${gId}'`;
    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        res.send({
            message: 'Data Deleted'
        })
    })
})

// update details.....//

app.get('/tableupdate', (req, res) => {
    let qr = `select * from tableupdate`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'all book data',
                data: result
            })
        }
    })
})
app.get('/tableupdate/:id', (req, res) => {

    let gId = req.params.id;

    let qr = `select * from tableupdate where id = ${gId}`

    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'Get single data',
                data: result
            })
        }
        else {
            res.send({
                message: 'data not found'
            })
        }
    })
})
app.post('/tableupdate', (req, res) => {

    console.log(req.body, 'createdata');

    let year = req.body.year;
    let response = req.body.response;
    let status = req.body.status;
    let visit = req.body.visit;
    let ppt = req.body.ppt;
    let cash = req.body.cash;
    let hname = req.body.hname;
    let date = req.body.date;

    let qr = ` insert into tableupdate (year,response,status,visit,ppt,cash,hname,date) 
                    values ( '${year}' ,'${response}','${status}','${visit}' ,'${ppt}','${cash}','${hname}','${date}'     )`;

    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        console.log(result, 'result')
        res.send({
            message: 'Data Inserted'
        })
    })
})
app.put('/tableupdate/:id', (req, res) => {
    console.log(req.body, 'updatedata');

    let gId = req.params.id;
    let year = req.body.year;
    let response = req.body.response;
    let status = req.body.status;
    let visit = req.body.visit;
    let ppt = req.body.ppt;
    let cash = req.body.cash;
    let hname = req.body.hname;
    let date = req.body.date;

    let qr = `update tableupdate set year = '${year}' ,response = '${response}' ,status = '${status}',visit = '${visit}',ppt = '${ppt}',cash = '${cash}',hname = '${hname}',date = '${date}'
                    where id = ${gId}`;

    db.query(qr, (err, result) => {
        if (err) { console.log('err') }
        res.send({
            message: 'Data updated'
        })
    })
})
//delete data
app.delete('/tableupdate/:id', (req, res) => {
    let gId = req.params.id;
    let qr = `delete from tableupdate where id = '${gId}'`;
    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        res.send({
            message: 'Data Deleted'
        })
    })
})
// document details.....//

app.get('/document', (req, res) => {
    let qr = `select * from document`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'all book data',
                data: result
            })
        }
    })
})
app.get('/document/:id', (req, res) => {

    let gId = req.params.id;

    let qr = `select * from document where id = ${gId}`

    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'Get single data',
                data: result
            })
        }
        else {
            res.send({
                message: 'data not found'
            })
        }
    })
})

app.post('/document', (req, res) => {

    console.log(req.body, 'createdata');

    let name = req.body.name;
    let url = req.body.url;
    let date = req.body.date;

    let qr = ` insert into document (name,url,date) 
                values ( '${name}' ,'${url}','${date}' )`;

    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        console.log(result, 'result')
        res.send({
            message: 'Data Inserted'
        })
    })
})
app.put('/document/:id', (req, res) => {
    console.log(req.body, 'updatedata');

    let gId = req.params.id;
    let name = req.body.name;
    let url = req.body.url;
    let date = req.body.date;

    let qr = `update document set name = '${name}' ,url = '${url}' ,date = '${date}'
                    where id = ${gId}`;

    db.query(qr, (err, result) => {
        if (err) { console.log('err') }
        res.send({
            message: 'Data updated'
        })
    })
})

//delete data
app.delete('/document/:id', (req, res) => {
    let gId = req.params.id;
    let qr = `delete from document where id = '${gId}'`;
    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        res.send({
            message: 'Data Deleted'
        })
    })
})

// notes details.....//

app.get('/notes', (req, res) => {
    let qr = `select * from notes`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'all book data',
                data: result
            })
        }
    })
})
app.get('/notes/:id', (req, res) => {

    let gId = req.params.id;

    let qr = `select * from notes where id = ${gId}`

    db.query(qr, (err, result) => {
        if (err) {
            console.log(err);
        }
        if (result.length > 0) {
            res.send({
                message: 'Get single data',
                data: result
            })
        }
        else {
            res.send({
                message: 'data not found'
            })
        }
    })
})

app.post('/notes', (req, res) => {

    console.log(req.body, 'createdata');

    let notes = req.body.notes;
    let date = req.body.date;

    let qr = ` insert into notes (notes,date) 
            values ( '${notes}','${date}' )`;

    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        console.log(result, 'result')
        res.send({
            message: 'Data Inserted'
        })
    })
})

app.put('/notes/:id', (req, res) => {
    console.log(req.body, 'updatedata');

    let gId = req.params.id;
    let notes = req.body.notes;
    let date = req.body.date;


    let qr = `update notes set notes = '${notes}' ,date = '${date}' 
        where id = ${gId}`;

    db.query(qr, (err, result) => {
        if (err) { console.log('err') }
        res.send({
            message: 'Data updated'
        })
    })
})

//delete data
app.delete('/notes/:id', (req, res) => {
    let gId = req.params.id;
    let qr = `delete from notes where id = '${gId}'`;
    db.query(qr, (err, result) => {
        if (err) { console.log(err) }
        res.send({
            message: 'Data Deleted'
        })
    })
})





app.listen(3000, () => {
    console.log(`Server is running `)
})






