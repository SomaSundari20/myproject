module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "book",
    dialect: "mysql",
    pool: {
        min: 0,
        max: 5,
    }

}


